
hsdSpedApp.controller('socialServiceController',[
    '$scope','spedService',
        function($scope,service){
            //var studentid=~(curstudid);
            class CaseManager{
                constructor(dcid, name, selected){
                    this.dcid=dcid;
                    this.name=name;
                    this.selected=selected;
                }
            }
            class Codeset{
                constructor(codeset,selected){
                    this.Code=codeset.code;
                    this.description=codeset.displayvalue;
                    this.selected=selected;
                }
            }
            setTimeout(function(){
                service.getStudentSocialServiceInfo($scope.id).then(function(student){
                    service.getCaseManagers().then(function(managers){
                        $scope.caseManagers=[];
                        $scope.relatedServiceCaseManagers=[];
                        managers.forEach(function(manager){
                            if (manager.case_manager==1){
                                if(student.case_manager==manager.dcid){
                                    $scope.caseManagers.push(new CaseManager(manager.dcid,manager.lastfirst,true));
                                }else{
                                    $scope.caseManagers.push(new CaseManager(manager.dcid,manager.lastfirst,false));
                                }
                            }
                            if (manager.related_service_case_manager==1){
                                if(student.related_service_case_manager==manager.dcid){
                                    $scope.relatedServiceCaseManagers.push(new CaseManager(manager.dcid,manager.lastfirst,true));
                                }else{
                                    $scope.relatedServiceCaseManagers.push(new CaseManager(manager.dcid,manager.lastfirst,false));
                                }
                            }
                        })
                    })
    
                    service.getHandicaps().then(function(handicaps){
                        $scope.Handicaps1=[];
                        $scope.Handicaps2=[];
                        handicaps.forEach(function(handicap){
                                if(student.handicap1==handicap.code){
                                    $scope.Handicaps1.push(new Codeset(handicap,true));
                                }else{
                                    $scope.Handicaps1.push(new Codeset(handicap,false));
                                }
                            
                                if(student.handicap2==handicap.code){
                                    $scope.Handicaps2.push(new Codeset(handicap,true));
                                }else{
                                    $scope.Handicaps2.push(new Codeset(handicap,false));
                                }
                        })
                    })
                    service.getSpedPrekCategories().then(function(categories){
                        $scope.categories=[];
                        categories.forEach(function(category){
                            if(student.prek_category==category.code){
                                $scope.categories.push(new Codeset(category,true))
                            }else{
                                $scope.categories.push(new Codeset(category,false))
                            }
                        })
                    })
                })
            },100)
        }
])
