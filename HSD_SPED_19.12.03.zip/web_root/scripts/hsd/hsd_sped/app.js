'use strict';
//require(['angular','components/shared/index'],function (angular){
var hsdSpedApp=angular.module('hsdSpedApp',[]);
//})
