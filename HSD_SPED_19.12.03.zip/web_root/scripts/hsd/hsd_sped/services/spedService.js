
    hsdSpedApp.factory('spedService',['$http',
        function($http){
            return{
                getCaseManagers: function(){
                    return $http.post('/ws/schema/query/org.helenaschools.hsd_sped.socialservice.casemanagers',{},{headers :{'content-type':'application/json'} }).then(
                        function(data){
                            return data.data.record;
                        });
                },
                getHandicaps:function(){
                    return $http.post('/ws/schema/query/org.helenaschools.hsd_sped.socialservice.handicaps',{},{headers:{'content-type':'application/json'}}).then(
                        function(data){
                            return data.data.record;
                        });
                },
                getSpedPrekCategories:function(){
                    return $http.post('/ws/schema/query/org.helenaschools.hsd_sped.socialService.prekCategories',{},{headers:{'content-type':'application/json'}}).then(
                        function(data){
                            return data.data.record;
                        }
                    )
                },
                getStudentSocialServiceInfo:function(studentid){
                    var data;
                    if(studentid===undefined){
                       data={}
                   }else{
                        data={"studentid":studentid}
                   }
                    return $http.post('/ws/schema/query/org.helenaschools.hsd_sped.socialservice.studentSocialServiceInfo',data,{headers:{'content-type':'application/json'}}).then(
                        function(data){
                            if(data.data.record !== undefined){
                                return data.data.record[0];
                            }
                            return data;
                        });
                }
            }
        }])
